"""Stage 3.1 targeted follow-up checks. Development evidence only."""

from __future__ import annotations

import copy
import hashlib
from collections import defaultdict
from pathlib import Path
from typing import Any

from f1q.errors import RejectionError, ResourceCeilingError
from f1q.hashing import canonical_json, sha256_json
from f1q.paths import resolve_within
from f1q.simulator.checks import (
    TOL_FINISH_S,
    TOL_FREE_TRACK_ANALYTIC_S,
    TOL_PIT_EVENT_S,
    run_all_mechanism_checks,
)
from f1q.simulator.config import load_simulator_config
from f1q.simulator.engine import distance, draw_uniform
from f1q.simulator.fuel import horizon_need_kg, realize_initial_fuel
from f1q.simulator.hand_specs import build_hand_spec
from f1q.simulator.interface import RaceSimulator
from f1q.simulator.matrix import PREVIEW_RUN, intervention_episodes, load_preview_specs
from f1q.simulator.resources import MemoryGuard

PIT_EVENT_KINDS = ("pit_entry", "service_start", "service_complete", "pit_exit", "pit_wait")
CRITERIA = {
    "recorded_before_resolution_execution": True,
    "free_track_analytic_tolerance_s": TOL_FREE_TRACK_ANALYTIC_S,
    "free_track_tolerance_kind": "floating_point_and_newton_truncation_not_time_discretization",
    "pit_event_finest_pair_target_s": TOL_PIT_EVENT_S,
    "finish_time_finest_pair_target_s": TOL_FINISH_S,
    "pit_event_kinds": list(PIT_EVENT_KINDS),
    "step_refinement": ["h", "h/2", "h/4"],
    "event_keyed_draws": "fuel_actual_offset and regime_duration stay stream-keyed; not redrawn on refine",
    "event_correspondence": "match by (kind, car_id) occurrence index; traces are not re-sorted per resolution",
    "ambiguity_band_s": 0.05,
    "ambiguity_note": "Deliberate ties/near-ties are reported separately; tolerances are not widened to hide flips.",
    "not_campaign_monte_carlo": True,
    "not_team_supplied_tolerances": True,
}


def select_resolution_panel(specs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Hash-select one episode per family, 4 SC / 4 VSC where possible. No outcome inspection."""
    selected = intervention_episodes(specs)
    return selected


def resolution_panel_ids(specs: list[dict[str, Any]]) -> dict[str, Any]:
    selected = select_resolution_panel(specs)
    return {
        "rule": "sha256(episode_id) min within family; even families SC, odd families VSC",
        "count": len(selected),
        "episode_ids": [s["episode_id"] for s in selected],
        "families": [s["family_id"] for s in selected],
        "regimes": [s["checkpoint_request"]["requested_regime"] for s in selected],
        "selected_before_resolution_outcomes": True,
    }


def _cfg_scaled(cfg: dict[str, Any], denom: int) -> dict[str, Any]:
    out = copy.deepcopy(cfg)
    out["integrator"]["dt_max_green_s"] = float(cfg["integrator"]["dt_max_green_s"]) / denom
    out["integrator"]["dt_max_regime_s"] = float(cfg["integrator"]["dt_max_regime_s"]) / denom
    out["integrator"]["step_label"] = {1: "h", 2: "h/2", 4: "h/4"}[denom]
    return out


def _index_events(events: list[dict[str, Any]]) -> dict[tuple[str, str], list[float]]:
    grouped: dict[tuple[str, str], list[float]] = defaultdict(list)
    for event in events:
        kind = str(event.get("kind"))
        if kind not in PIT_EVENT_KINDS:
            continue
        key = (kind, str(event.get("car_id")))
        grouped[key].append(float(event["t"]))
    return grouped


def _max_matched_error(
    a: dict[tuple[str, str], list[float]], b: dict[tuple[str, str], list[float]]
) -> dict[str, Any]:
    keys = set(a) | set(b)
    max_err = None
    n_matched = 0
    missing = []
    for key in sorted(keys):
        la, lb = a.get(key, []), b.get(key, [])
        if not la or not lb:
            missing.append({"kind": key[0], "car_id": key[1], "n_a": len(la), "n_b": len(lb)})
            continue
        for ta, tb in zip(la, lb, strict=False):
            err = abs(ta - tb)
            max_err = err if max_err is None else max(max_err, err)
            n_matched += 1
        if len(la) != len(lb):
            missing.append({"kind": key[0], "car_id": key[1], "n_a": len(la), "n_b": len(lb), "count_mismatch": True})
    return {
        "max_abs_error_s": max_err,
        "matched_pairs": n_matched,
        "absent_or_count_mismatch": missing,
        "quantity_absent": max_err is None,
    }


def _run_episode(cfg: dict[str, Any], spec: dict[str, Any]) -> dict[str, Any]:
    sim = RaceSimulator(cfg)
    sim.initialize(spec)
    sim.advance_to_checkpoint()
    _, out = sim.continue_to_finish()
    events = sim.engine.state["events"]
    ranks = out["ranking"]["ranks"]
    legality = not any(e["kind"] == "pit_now_expired" and e.get("detail", {}).get("not_relabelled_next_lap") is False for e in events)
    return {
        "finish_t": out["t"],
        "finish_times": out["finish_time"],
        "ranks": ranks,
        "events": _index_events(events),
        "event_kinds_present": sorted({e["kind"] for e in events}),
        "classification_order": out["ranking"]["order"],
        "legality_ok": legality,
    }


def run_resolution_panel(root: Path, panel_specs: list[dict[str, Any]], cfg: dict[str, Any]) -> dict[str, Any]:
    denoms = (1, 2, 4)
    rows = []
    flips = []
    for spec in panel_specs:
        by_den = {}
        for den in denoms:
            by_den[den] = _run_episode(_cfg_scaled(cfg, den), spec)
        h, h2, h4 = by_den[1], by_den[2], by_den[4]
        pit_h_h2 = _max_matched_error(h["events"], h2["events"])
        pit_h2_h4 = _max_matched_error(h2["events"], h4["events"])
        finish_err_h2_h4 = max(abs(h2["finish_times"][c] - h4["finish_times"][c]) for c in h2["finish_times"])
        finish_err_h_h4 = max(abs(h["finish_times"][c] - h4["finish_times"][c]) for c in h["finish_times"])
        rank_flip = h2["ranks"] != h4["ranks"] or h["ranks"] != h4["ranks"]
        order_flip = h2["classification_order"] != h4["classification_order"]
        if rank_flip or order_flip:
            flips.append(
                {
                    "episode_id": spec["episode_id"],
                    "rank_flip": rank_flip,
                    "order_flip": order_flip,
                    "ambiguity_band_s": CRITERIA["ambiguity_band_s"],
                    "finish_err_h2_h4": finish_err_h2_h4,
                }
            )
        pit_absent = pit_h2_h4["quantity_absent"]
        pit_ok = pit_absent or (
            pit_h2_h4["max_abs_error_s"] is not None and pit_h2_h4["max_abs_error_s"] <= TOL_PIT_EVENT_S
        )
        finish_ok = finish_err_h2_h4 <= TOL_FINISH_S
        rows.append(
            {
                "episode_id": spec["episode_id"],
                "family_id": spec["family_id"],
                "regime": spec["checkpoint_request"]["requested_regime"],
                "pit_events_h_vs_h2": pit_h_h2,
                "pit_events_h2_vs_h4": pit_h2_h4,
                "pit_quantity": "absent" if pit_absent else "pit_entry/service/rejoin event times",
                "finish_max_abs_error_h2_h4_s": finish_err_h2_h4,
                "finish_max_abs_error_h_h4_s": finish_err_h_h4,
                "rank_flip_h_h2_h4": rank_flip,
                "order_flip_h_h2_h4": order_flip,
                "legality_stable": h["legality_ok"] and h2["legality_ok"] and h4["legality_ok"],
                "pit_gate": "N/A" if pit_absent else ("PASS" if pit_ok else "FAIL"),
                "finish_gate": "PASS" if finish_ok else "FAIL",
                "supports_refinement": (not pit_absent)
                and pit_h2_h4["max_abs_error_s"] is not None
                and pit_h_h2["max_abs_error_s"] is not None
                and pit_h2_h4["max_abs_error_s"] <= pit_h_h2["max_abs_error_s"] + 1e-12,
            }
        )
    pit_errors = [r["pit_events_h2_vs_h4"]["max_abs_error_s"] for r in rows if r["pit_events_h2_vs_h4"]["max_abs_error_s"] is not None]
    finish_errors = [r["finish_max_abs_error_h2_h4_s"] for r in rows]
    pit_fail = any(r["pit_gate"] == "FAIL" for r in rows)
    finish_fail = any(r["finish_gate"] == "FAIL" for r in rows)
    if pit_fail or finish_fail:
        status = "FAIL"
    elif any(r["rank_flip_h_h2_h4"] for r in rows):
        status = "PARTIAL"
    else:
        status = "PASS"
    return {
        "status": status,
        "criteria": CRITERIA,
        "max_pit_event_error_h2_h4_s": max(pit_errors) if pit_errors else None,
        "max_finish_error_h2_h4_s": max(finish_errors) if finish_errors else None,
        "episodes_with_no_pit_events": sum(1 for r in rows if r["pit_gate"] == "N/A"),
        "rank_or_order_flips": flips,
        "rows": rows,
        "two_levels_do_not_prove_convergence": True,
    }


def run_fuel_audit(root: Path, cfg: dict[str, Any]) -> dict[str, Any]:
    specs = load_preview_specs(root)
    rows = []
    floors = 0
    rejections = 0
    errors = []
    at_threshold = 0
    for spec in specs:
        init = spec["initialization"]
        remaining = int(init["remaining_laps"])
        need = horizon_need_kg(remaining, float(cfg["fuel"]["kg_per_lap"]))
        completed_init = int(init["completed_laps"])
        per_car = []
        rejected = None
        try:
            sim = RaceSimulator(cfg)
            sim.initialize(spec)
            for row in spec["field"]:
                cid = row["car_id"]
                est = float(row["fuel_kg"])
                u = float(row["fuel_uncertainty_kg"])
                offset = draw_uniform(
                    spec,
                    event_type="fuel_actual_offset",
                    driver_id=cid,
                    lap=completed_init,
                    low=-u,
                    high=u,
                )
                realized = realize_initial_fuel(
                    estimate_kg=est, uncertainty_kg=u, offset_kg=offset, need_kg=need, car_id=cid
                )
                actual = float(sim.engine.state["cars"][cid]["fuel_actual"])
                if abs(actual - realized.actual_kg) > 1e-9:
                    raise AssertionError(f"{cid} engine actual != realization")
                if realized.floor_applied:
                    floors += 1
                if abs(realized.actual_kg - need) <= 1e-9:
                    at_threshold += 1
                errors.append(realized.error_kg)
                per_car.append(
                    {
                        "car_id": cid,
                        "estimate_kg": est,
                        "actual_fuel": actual,
                        "need_kg": need,
                        "offset_kg": offset,
                        "error_kg": realized.error_kg,
                        "floor_applied": realized.floor_applied,
                        "provisional_actual_kg": realized.provisional_actual_kg,
                    }
                )
        except RejectionError as exc:
            rejected = f"{exc.code}: {exc.reason}"
            rejections += 1
        rows.append(
            {
                "episode_id": spec["episode_id"],
                "need_kg": need,
                "need_source": "remaining_laps_at_init * kg_per_lap",
                "rejected": rejected,
                "cars": per_car,
            }
        )
    edge = _fuel_edge_cases()
    public_rows = []
    for row in rows:
        public_rows.append(
            {
                "episode_id": row["episode_id"],
                "need_kg": row["need_kg"],
                "rejected": row["rejected"],
                "floor_count": sum(1 for c in row["cars"] if c["floor_applied"]),
                "error_min_kg": min((c["error_kg"] for c in row["cars"]), default=None),
                "error_max_kg": max((c["error_kg"] for c in row["cars"]), default=None),
                "cars_at_threshold": sum(1 for c in row["cars"] if abs(c["error_kg"] + (c["estimate_kg"] if False else 0)) or abs((c.get("actual_fuel") or 0) - row["need_kg"]) <= 1e-9),
            }
        )
        # recompute at-threshold without relying on the messy expression
        public_rows[-1]["cars_at_threshold"] = sum(
            1 for c in row["cars"] if abs(c["actual_fuel"] - row["need_kg"]) <= 1e-9
        )
    return {
        "preview_run_id": PREVIEW_RUN,
        "n_specs": len(specs),
        "n_cars": sum(len(r["cars"]) for r in rows),
        "floor_applied_count": floors,
        "rejection_count": rejections,
        "cars_with_mass_at_need_threshold": at_threshold,
        "error_min_kg": min(errors) if errors else None,
        "error_max_kg": max(errors) if errors else None,
        "unbiased_uniform_error": False,
        "conditioned_fictional_corpus": True,
        "need_uses_future_draws": False,
        "amendment": "development_spec.fuel.v1.1",
        "generation_unchanged_from_v1": True,
        "edge_cases": edge,
        "public_per_spec": public_rows,
        "private_rows": rows,
    }


def _fuel_edge_cases() -> dict[str, Any]:
    cases = []

    def one(name, **kwargs):
        try:
            got = realize_initial_fuel(**kwargs)
            cases.append({"name": name, "ok": True, "floor_applied": got.floor_applied, "actual_kg": got.actual_kg, "error_kg": got.error_kg})
        except RejectionError as exc:
            cases.append({"name": name, "ok": True, "rejected": exc.code})

    one("interior_above_need", estimate_kg=20.0, uncertainty_kg=2.0, offset_kg=-1.0, need_kg=18.0)
    one("floor_to_need", estimate_kg=18.0, uncertainty_kg=2.0, offset_kg=-1.5, need_kg=18.0)
    one("exact_need_no_floor", estimate_kg=18.0, uncertainty_kg=2.0, offset_kg=0.0, need_kg=18.0)
    one("offset_hits_need", estimate_kg=20.0, uncertainty_kg=2.0, offset_kg=-2.0, need_kg=18.0)
    one("impossible_band", estimate_kg=15.0, uncertainty_kg=2.0, offset_kg=0.0, need_kg=18.0)
    atom = 0
    interior = 0
    for i in range(41):
        offset = -2.0 + i * 0.1
        got = realize_initial_fuel(estimate_kg=20.0, uncertainty_kg=2.0, offset_kg=offset, need_kg=19.0)
        if got.floor_applied:
            atom += 1
        else:
            interior += 1
    expected_atom = sum(1 for i in range(41) if (-2.0 + i * 0.1) < -1.0 - 1e-12)
    return {
        "hand_cases": cases,
        "grid_estimate20_need19_u2": {
            "n": 41,
            "floor_atom_count": atom,
            "interior_count": interior,
            "expected_floor_when_offset_lt_-1": expected_atom,
            "atom_matches_truncated_uniform": atom == expected_atom,
            "note": "Floor replaces Uniform undershoot with an atom at need; error is not Uniform(-u,u).",
        },
        "pass": all("rejected" in c or c.get("ok") for c in cases)
        and cases[1]["floor_applied"] is True
        and abs(cases[1]["actual_kg"] - 18.0) <= 1e-12
        and cases[4].get("rejected") == "IMPOSSIBLE_INITIAL_FUEL"
        and atom == expected_atom,
    }


def run_shared_crew_end_to_end(cfg: dict[str, Any]) -> dict[str, Any]:
    spec = build_hand_spec(
        spec_id="hand.shared_e2e",
        episode_id="hand.shared_e2e/ep/SC",
        mean_gap_ahead_s=0.04,
        obligation=1,
        remaining_at_checkpoint=8,
        laps_until_checkpoint=1,
        selected_positions=(1, 2),
    )
    stacked = RaceSimulator(cfg)
    stacked.initialize(spec)
    a, b = spec["selected_car_ids"]
    stacked.apply_plan(
        {
            a: {"kind": "pit_now", "compound": "medium", "set_id": f"{a}.set.medium.0"},
            b: {"kind": "pit_now", "compound": "medium", "set_id": f"{b}.set.medium.0"},
        }
    )
    steps = 0
    while steps < 300_000:
        exits = [e for e in stacked.engine.state["events"] if e["kind"] == "pit_exit" and e["car_id"] in {a, b}]
        if len(exits) >= 2:
            break
        stacked.engine.tick()
        steps += 1
    waits = {cid: float(stacked.engine.state["cars"][cid]["service_wait_s"]) for cid in (a, b)}
    exit_t = {}
    for event in stacked.engine.state["events"]:
        if event["kind"] == "pit_exit" and event["car_id"] in {a, b}:
            exit_t.setdefault(event["car_id"], float(event["t"]))
    wait_max = max(waits.values())
    if len(exit_t) == 2:
        dt_exit = abs(exit_t[a] - exit_t[b])
        propagated = dt_exit + 1e-6 >= wait_max
    else:
        dt_exit = None
        propagated = False
    return {
        "pass": propagated and wait_max >= 0.0 and len(exit_t) == 2,
        "service_wait_s": waits,
        "pit_exit_race_s": exit_t,
        "exit_time_gap_s": dt_exit,
        "wait_propagated_into_rejoin_time": propagated,
        "note": "Time effect only; rank change is not required.",
    }


def execute_followup_unit(
    *,
    root: Path,
    run_id: str,
    unit_id: str,
    seed: int,
    attempt_id: str,
    dest: Path,
    guard: MemoryGuard,
) -> dict[str, Any]:
    del seed, attempt_id
    cfg, cfg_hash = load_simulator_config(root)
    guard.observe()
    if unit_id == "simulator.followup.criteria":
        specs = load_preview_specs(root)
        panel = resolution_panel_ids(specs)
        payload = {
            "ok": True,
            "criteria": CRITERIA,
            "resolution_panel": panel,
            "simulator_config_hash": cfg_hash,
            "preview_run_id": PREVIEW_RUN,
            "original_stage3_run_id": "e2258740-1d08-4427-8305-b149ed504a73",
            "original_stage3_snapshot": "26ed935ce0dbba00963bbe5766c77f1247fed491d2a9cf697f692c1cf5a4e6c1",
            "stage3_identifiers_not_overwritten": True,
        }
        return payload
    if unit_id == "simulator.followup.fuel":
        audit = run_fuel_audit(root, cfg)
        private = audit.pop("private_rows")
        dest.mkdir(parents=True, exist_ok=True)
        private_rel = dest / "fuel_private_audit.json"
        from f1q.hashing import atomic_write_bytes

        atomic_write_bytes(private_rel, canonical_json({"rows": private, "solver_must_not_read": True}) + b"\n")
        audit["ok"] = audit["rejection_count"] == 0 and audit["edge_cases"]["pass"]
        audit["private_audit_filename"] = "fuel_private_audit.json"
        audit["private_values_not_in_solver_observation"] = True
        return audit
    if unit_id == "simulator.followup.resolution":
        specs = load_preview_specs(root)
        selected = select_resolution_panel(specs)
        report = run_resolution_panel(root, selected, cfg)
        report["ok"] = report["status"] in {"PASS", "PARTIAL"}
        report["panel_episode_ids"] = [s["episode_id"] for s in selected]
        return report
    if unit_id == "simulator.followup.behavioral":
        from f1q.simulator.checks import check_causal, check_resume, check_rng

        causal = check_causal(cfg)
        resume = check_resume(cfg)
        rng = check_rng(cfg)
        return {
            "ok": causal["pass"] and resume["pass"] and rng["pass"],
            "causal": causal,
            "resume_fresh_process_still_required": "tests/test_simulator_mechanisms.py::test_resume_equivalence_in_fresh_process",
            "resume": resume,
            "randomness_branch_isolation": rng,
        }
    if unit_id == "simulator.followup.commitment":
        from f1q.simulator.checks import check_deadline

        deadline = check_deadline(cfg)
        return {"ok": deadline["pass"], "deadline": deadline}
    if unit_id == "simulator.followup.sc_vsc_traffic":
        from f1q.simulator.checks import check_sc_vsc, check_shared_service, check_traffic

        sc = check_sc_vsc(cfg)
        traffic = check_traffic(cfg)
        shared = check_shared_service(cfg)
        e2e = run_shared_crew_end_to_end(cfg)
        return {
            "ok": sc["pass"] and traffic["pass"] and shared["pass"] and e2e["pass"],
            "sc_vsc": sc,
            "traffic_rejoin": traffic,
            "shared_service": shared,
            "shared_crew_end_to_end": e2e,
        }
    if unit_id == "simulator.followup.memory":
        mech = run_all_mechanism_checks(cfg)
        summary = guard.summary()
        payload = {
            "ok": mech.get("ok") and not (summary.get("last") or {}).get("over_ceiling"),
            "mechanism_regressions_ok": mech.get("ok"),
            "failed_mechanism_checks": mech.get("failed"),
            "memory": summary,
            "workers": 1,
            "elapsed_cap_s": float(cfg["resource"]["stage3_elapsed_cap_s"]),
            "ram_ceiling_fraction": float(cfg["resource"]["ram_ceiling_fraction"]),
        }
        return payload
    raise ValueError(f"unknown followup unit {unit_id}")
