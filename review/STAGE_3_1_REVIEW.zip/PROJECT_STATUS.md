# Project status

Updated after Stage 3.1. Chat recollection is not evidence.

## Active stage

Stage 3.1 complete as software with one **PARTIAL** resolution-rank gate. Stage 4 is **not authorised**.

## Completed work with evidence

- Isolated repository `f1-ai-quantum-strategy` on `main`, remote origin connected, **not pushed**
- Dossier v3.1 SHA-256 `2c6fd0851d12a281bb7f7bad7d4cc522f4606a3c3df32c43cad1ca9146b83b76`, 33/33 pages extracted
- Stage 1 follow-up: `docs/STAGE_1_FOLLOWUP.md` (PASS); unrepaired bootstrap `doctor.py` bytes limitation preserved
- Stage 2 development-preview run `8f292588-a328-4232-b425-c36c610a29f5`: 8 blocks, 64 specifications, original files not overwritten
- Stage 3 simulator-check run `e2258740-1d08-4427-8305-b149ed504a73`: preserved; not recomputed under that identifier
- Stage 3.1 simulator-followup run `4388ad68-6bd3-4a43-9099-32e52f56eb28`: fuel audit, resolution panel (PARTIAL rank flip), behavioral isolation, common commitment, SC/VSC/traffic, memory sampling
- Receipt: `evidence/simulator/receipts/4388ad68-6bd3-4a43-9099-32e52f56eb28.json`
- pytest 75 passed (`docs/evidence/stage3_1/pytest.txt`)
- Named Stage 3.1 record: `docs/STAGE_3_1_REPORT.md`

The Stage 3.1 source snapshot is `2b56232734cc38be22a0aab9a5e16f3c0a7afbff731382b204a60c2d797dbf00` at git `358a17b1a03d53248c5dd81305c24db384691f9b` with a dirty tree at run time. Git HEAD alone does not identify a dirty tree.

## Protocol state

- scientific_protocol: DRAFT
- frozen: false
- hardware_execution_enabled: false
- research comparison experiments executed: 0
- physical QPU jobs submitted: 0
- QPU usage from this stage: 0 seconds; account balance not queried

## Blocking findings

Resolution rank-stability is PARTIAL (one near-tie rank flip under h/h2/h4). Real-world calibration was not run. GitHub push is not authorised. Reserved scientific partitions are not materialized. Stage 4 awaits its implementation prompt and review of these findings.

## Next authorised unit

None. Stage 3.1 findings await review. Stage 4 (action model, QUBO, independent classical references) awaits its implementation prompt.

## Files a future Agent must read first

1. `AGENTS.md`
2. `PROJECT_STATUS.md`
3. `docs/STAGE_3_1_REPORT.md`
4. `docs/STAGE_3_REPORT.md`
5. `docs/SIMULATOR_VALIDATION.md`
6. `docs/SIMULATOR_SELECTION.md`
7. `docs/SIMULATOR_MODEL.md`
8. `docs/STAGE_2_REPORT.md`
9. `docs/protocol/SOURCE_HASH.md`
10. `python -m f1q status` and `python -m f1q doctor`
